"""Inference entry points."""
