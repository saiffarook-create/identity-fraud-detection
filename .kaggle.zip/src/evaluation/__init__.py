"""Model evaluation helpers."""
